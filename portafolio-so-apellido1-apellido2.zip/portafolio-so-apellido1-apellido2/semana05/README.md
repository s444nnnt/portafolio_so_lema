# Semana 05

Pendiente.

- [ ] comandos.md
- [ ] teoria.md
- [ ] scripts
