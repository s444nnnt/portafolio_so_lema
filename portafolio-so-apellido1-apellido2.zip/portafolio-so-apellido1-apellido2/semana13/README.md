# Semana 13

Pendiente.

- [ ] comandos.md
- [ ] teoria.md
- [ ] scripts
