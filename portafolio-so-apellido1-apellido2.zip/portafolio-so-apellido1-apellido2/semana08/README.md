# Semana 08

Pendiente.

- [ ] comandos.md
- [ ] teoria.md
- [ ] scripts
