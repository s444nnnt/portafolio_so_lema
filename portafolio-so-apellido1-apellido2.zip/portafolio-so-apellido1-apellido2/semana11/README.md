# Semana 11

Pendiente.

- [ ] comandos.md
- [ ] teoria.md
- [ ] scripts
