# Portafolio de Sistemas Operativos

**Escuela Politécnica Nacional · FIEE**
**Integrantes:** Apellido1 Nombre1 · Apellido2 Nombre2
**Periodo:** 2026

Portafolio de scripts de administración y notas de la materia. Cada semana tiene su carpeta con README, comandos, teoría y scripts.

## Estructura

```text
portafolio-so-apellido1-apellido2/
├── README.md
├── semana01/
│   ├── README.md          # resumen y cómo ejecutar
│   ├── comandos.md        # comandos Linux y Windows (obligatorio)
│   ├── teoria.md          # apuntes de teoría
│   ├── inventario.sh      # inventario de hardware (Bash)
│   ├── inventario.ps1     # inventario de hardware (PowerShell)
│   └── calc_rendimiento.py# calculadora CPI, MIPS, Amdahl, AMAT
├── semana02/
├── ...
└── semana16/
```

## Índice de semanas

| Semana | Tema | Estado |
|--------|------|--------|
| [01](semana01/) | Arquitectura de computadoras | ✅ |
| 02 | Modelo de programación, jerarquía de memoria, representación de datos | ⏳ |
| 03 – 16 | Por completar | ⏳ |

## Guía rápida de Git

```bash
git clone https://github.com/<usuario>/portafolio-so-apellido1-apellido2.git
cd portafolio-so-apellido1-apellido2
git add .
git commit -m "semana01: agrega inventario.sh y comandos.md"
git push origin main
```

> Ambos integrantes deben hacer commits (parte de la rúbrica).
