# Semana 07

Pendiente.

- [ ] comandos.md
- [ ] teoria.md
- [ ] scripts
