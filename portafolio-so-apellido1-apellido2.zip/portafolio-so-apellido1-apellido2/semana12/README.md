# Semana 12

Pendiente.

- [ ] comandos.md
- [ ] teoria.md
- [ ] scripts
