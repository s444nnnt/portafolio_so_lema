# Semana 16

Pendiente.

- [ ] comandos.md
- [ ] teoria.md
- [ ] scripts
