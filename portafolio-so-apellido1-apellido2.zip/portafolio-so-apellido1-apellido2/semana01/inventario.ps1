# inventario.ps1 · Semana 1
# Genera un reporte de hardware en inventario_<equipo>.txt
# Uso: .\inventario.ps1   (si hay error de politica: Set-ExecutionPolicy -Scope Process Bypass)

$salida = "inventario_$env:COMPUTERNAME.txt"
$cpu = Get-CimInstance Win32_Processor | Select-Object -First 1
$os  = Get-CimInstance Win32_OperatingSystem

& {
    "== Equipo: $env:COMPUTERNAME | $(Get-Date)"
    "== SO: $($os.Caption) $($os.Version)"

    "== CPU"
    "Modelo: $($cpu.Name)"
    "Nucleos: $($cpu.NumberOfCores)"
    "Hilos (CPU logicas): $($cpu.NumberOfLogicalProcessors)"
    "Frecuencia maxima (MHz): $($cpu.MaxClockSpeed)"
    "Cache L2 (KB): $($cpu.L2CacheSize)"
    "Cache L3 (KB): $($cpu.L3CacheSize)"
    "Nota: Windows no expone L1 con Win32_Processor; ver lscpu en Linux o CPU-Z."

    "== RAM (GB): {0:N1}" -f ($os.TotalVisibleMemorySize / 1MB)

    "== Discos"
    Get-PhysicalDisk |
        Format-Table FriendlyName, MediaType, @{n='Tamano_GB'; e={[math]::Round($_.Size / 1GB, 1)}} |
        Out-String

    "== Red (extra)"
    Get-NetIPAddress -AddressFamily IPv4 |
        Format-Table InterfaceAlias, IPAddress |
        Out-String
} | Out-File -Encoding utf8 $salida

Write-Host "Reporte generado: $salida"
