#!/usr/bin/env python3
"""Calculadora de rendimiento · Semana 1.

Implementa las formulas del tema 1.3:
CPI, tiempo de CPU, MIPS, ley de Amdahl, AMAT y memoria direccionable.
Ejecutar: python3 calc_rendimiento.py
"""


def cpi_promedio(mezcla):
    """mezcla: lista de (frecuencia, cpi). Las frecuencias deben sumar 1."""
    return sum(frec * cpi for frec, cpi in mezcla)


def tiempo_cpu(ic, cpi, f_hz):
    """T = IC x CPI / f (segundos)."""
    return ic * cpi / f_hz


def mips(f_hz, cpi):
    """MIPS = f / (CPI x 10^6)."""
    return f_hz / (cpi * 1e6)


def amdahl(f, s):
    """Speedup = 1 / ((1 - f) + f / s)."""
    return 1 / ((1 - f) + f / s)


def amdahl_limite(f):
    """Speedup maximo cuando s -> infinito."""
    return 1 / (1 - f)


def amat(t_hit, h, penalizacion):
    """AMAT = t_hit + (1 - h) x penalizacion."""
    return t_hit + (1 - h) * penalizacion


def memoria_direccionable(bits_dir):
    """Bytes direccionables con n bits de direccion."""
    return 2 ** bits_dir


def main():
    mezcla = [(0.5, 1), (0.3, 2), (0.2, 3)]
    ic = 1e9

    print("== Ejercicio 1: CPU A (3 GHz) vs CPU B (4 GHz) ==")
    cpi_a = cpi_promedio(mezcla)
    cpi_b = cpi_promedio([(0.5, 1), (0.3, 3), (0.2, 4)])
    t_a = tiempo_cpu(ic, cpi_a, 3e9)
    t_b = tiempo_cpu(ic, cpi_b, 4e9)
    print(f"CPI A = {cpi_a:.2f}  T = {t_a:.3f} s  MIPS = {mips(3e9, cpi_a):.0f}")
    print(f"CPI B = {cpi_b:.2f}  T = {t_b:.3f} s  MIPS = {mips(4e9, cpi_b):.0f}")
    print(f"Speedup B/A = {t_a / t_b:.2f}x\n")

    print("== Ejercicio 2: Amdahl con f = 0.8 ==")
    print(f"8 nucleos: {amdahl(0.8, 8):.2f}x")
    print(f"Maximo:    {amdahl_limite(0.8):.2f}x\n")

    print("== Ejercicio 3: AMAT (t_hit = 1 ns, penalizacion = 100 ns) ==")
    for h in (0.95, 0.99):
        print(f"h = {h:.0%}: {amat(1, h, 100):.1f} ns")
    print()

    print("== Buses: memoria direccionable ==")
    for bits in (20, 32, 36):
        gib = memoria_direccionable(bits) / 2**30
        print(f"{bits} bits -> {gib:g} GiB")


if __name__ == "__main__":
    main()
