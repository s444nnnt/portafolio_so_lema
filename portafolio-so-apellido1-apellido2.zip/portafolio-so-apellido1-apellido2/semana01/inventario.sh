#!/usr/bin/env bash
# inventario.sh · Semana 1
# Genera un reporte de hardware en inventario_<equipo>.txt
# Uso: ./inventario.sh

salida="inventario_$(hostname).txt"

{
  echo "== Equipo: $(hostname) | $(date)"
  echo "== SO: $(. /etc/os-release; echo "$PRETTY_NAME")"

  echo "== CPU"
  lscpu | grep -E '^(Model name|CPU\(s\)|Thread|Core|CPU max MHz|CPU MHz|L1d|L1i|L2|L3)'

  echo "== Memoria"
  free -h | head -2

  echo "== Discos (ROTA: 1=HDD, 0=SSD)"
  lsblk -d -e 7 -o NAME,MODEL,SIZE,TYPE,ROTA

  echo "== Red (extra)"
  ip -brief addr
} > "$salida"

echo "Reporte generado: $salida"
