# Semana 15

Pendiente.

- [ ] comandos.md
- [ ] teoria.md
- [ ] scripts
