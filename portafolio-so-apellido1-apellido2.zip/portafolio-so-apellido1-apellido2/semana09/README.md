# Semana 09

Pendiente.

- [ ] comandos.md
- [ ] teoria.md
- [ ] scripts
