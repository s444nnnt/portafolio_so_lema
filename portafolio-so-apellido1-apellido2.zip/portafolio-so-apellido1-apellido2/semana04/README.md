# Semana 04

Pendiente.

- [ ] comandos.md
- [ ] teoria.md
- [ ] scripts
