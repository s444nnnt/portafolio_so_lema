# Semana 02

Pendiente.

- [ ] comandos.md
- [ ] teoria.md
- [ ] scripts
