# Semana 10

Pendiente.

- [ ] comandos.md
- [ ] teoria.md
- [ ] scripts
