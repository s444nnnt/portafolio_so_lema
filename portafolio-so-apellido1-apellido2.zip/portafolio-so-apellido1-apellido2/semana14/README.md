# Semana 14

Pendiente.

- [ ] comandos.md
- [ ] teoria.md
- [ ] scripts
