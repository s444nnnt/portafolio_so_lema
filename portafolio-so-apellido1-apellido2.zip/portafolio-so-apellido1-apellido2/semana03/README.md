# Semana 03

Pendiente.

- [ ] comandos.md
- [ ] teoria.md
- [ ] scripts
