# Semana 06

Pendiente.

- [ ] comandos.md
- [ ] teoria.md
- [ ] scripts
